# Dependencies
import json

# Load JSON
video_file = open('../Resources/youtube_response.json')
video_json = json.load(video_file)
