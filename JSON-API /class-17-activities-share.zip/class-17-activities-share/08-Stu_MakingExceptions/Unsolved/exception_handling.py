# Your assignment is to get the last line to print without changing any
# of the code below. Instead, wrap each line that throws an error in a
# try/except block.

# See this reference for a list of exceptions you can catch:
# https://docs.python.org/3/library/exceptions.html#bltin-exceptions

print("Infinity looks like + " + str(10 / 0) + ".")

print("I think her name was + " + name + "?")

print("Your name is a nonsense number. Look: " + int("Gabriel"))

print("You made it through the gauntlet--the message survived!")
