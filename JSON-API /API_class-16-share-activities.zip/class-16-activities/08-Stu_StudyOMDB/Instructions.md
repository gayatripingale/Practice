# Instructions

Read the OMDb documentation, and make a few API calls to
get some information about your favorite movie.

You are free to duplicate the demonstration, or explore
more freely, as you wish. Just be sure to print two or three
properties of the JSON you retrieve.

- - -

### Copyright

Coding Boot Camp © 2017. All Rights Reserved.
